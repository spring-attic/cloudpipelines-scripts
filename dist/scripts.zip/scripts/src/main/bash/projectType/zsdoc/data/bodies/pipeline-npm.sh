

set -o errexit
set -o errtrace
set -o pipefail

export NPM_BIN NODE_BIN
NPM_BIN="${NPM_BIN:-npm}"
NODE_BIN="${NODE_BIN:-node}"
APT_BIN="${APT_BIN:-apt-get}"
CURL_BIN="${CURL_BIN:-curl}"
SUDO_BIN="${SUDO_BIN:-sudo}"

export ARTIFACT_TYPE
ARTIFACT_TYPE="${SOURCE_ARTIFACT_TYPE_NAME}"
