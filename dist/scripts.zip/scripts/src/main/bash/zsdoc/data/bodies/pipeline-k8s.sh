

set -o errexit
set -o errtrace
set -o pipefail
