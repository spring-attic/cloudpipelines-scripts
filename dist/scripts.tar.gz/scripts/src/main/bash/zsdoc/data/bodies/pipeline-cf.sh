

set -o errexit
set -o errtrace
set -o pipefail
export RETRIEVE_STUBRUNNER_IDS_FUNCTION="${RETRIEVE_STUBRUNNER_IDS_FUNCTION:-retrieveStubRunnerIds}"

export CF_BIN
CF_BIN="${CF_BIN:-cf}"
export CF_CLI_URL
CF_CLI_URL="${CF_CLI_URL:-https://cli.run.pivotal.io/stable?release=linux64-binary&source=github}"
